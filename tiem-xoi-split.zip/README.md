# Tiệm Xôi Bến Dừa — cấu trúc file

Mở game: mở `index.html` bằng trình duyệt (hoặc qua local server).

## Cấu trúc

```
index.html          # HTML + CSS + HUD, load các script
js/
  core.js           # Dữ liệu game, player, camera, assets, vẽ chung
  ui.js             # Giao diện túi đồ, thanh ô nhanh, vòng lặp
  zones/
    farm.js         # Trang trại (60 ô, nhà bếp, vật nuôi)
    market.js       # Chợ
    kitchen.js      # Bếp nấu
    shop.js         # Quán bán
    hub.js          # Map làng chung (POI)
    pets.js         # Khu thú cưng
```

## Sửa map nào → mở file đó

| Map | File |
|-----|------|
| Trang trại | `js/zones/farm.js` |
| Chợ | `js/zones/market.js` |
| Bếp | `js/zones/kitchen.js` |
| Quán | `js/zones/shop.js` |
| Làng (hub) | `js/zones/hub.js` |
| Thú cưng | `js/zones/pets.js` |

Logic chung (đi bộ, túi đồ, công thức): `js/core.js` + `js/ui.js`.

Các zone ghi vào `G.zones` / `Z` và dùng chung `G.travelTo`, `G.drawPOI`.
